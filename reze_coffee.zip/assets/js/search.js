function search(){
    document.getElementById("container-fluid-5").style.display="block";
    document.getElementById("close-5").style.display="block";
    document.getElementById("menu-name-3").style.display = "none";
}
function search_close(){
    document.getElementById("container-fluid-5").style.display = "none";
    document.getElementById("close-5").style.display = "none";
    document.getElementById("menu-name-3").style.display = "block";
}