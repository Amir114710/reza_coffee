from django.contrib import admin
from .models import ContactUs , About


admin.site.register(ContactUs)
admin.site.register(About)

